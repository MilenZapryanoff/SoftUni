package cats;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class HouseTests {
    private static final String DEFAULT_NAME = "testHouse";
    private static final int DEFAULT_CAPACITY = 5;
    private List<Cat> cat;

    private static House addCatsToHouse() {
        House house = new House("My House", 2);
        house.addCat(new Cat("testCat1"));
        house.addCat(new Cat("testCat2"));
        return house;
    }

    @Before
    public void setUp() {
        House house = addCatsToHouse();
        cat = new ArrayList<>();
    }

    @Test
    public void testConstructor() {
        House house = new House(DEFAULT_NAME, DEFAULT_CAPACITY);
        Assert.assertEquals(house.getName(), DEFAULT_NAME);
        Assert.assertEquals(house.getCapacity(), DEFAULT_CAPACITY);
    }

    @Test(expected = NullPointerException.class)
    public void testConstructorWithEmptyName() {
        House house = new House(null, DEFAULT_CAPACITY);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorWithEmptyCapacity() {
        House house = new House(DEFAULT_NAME, -1);
    }

    @Test
    public void testGetCount() {
        House house = addCatsToHouse();
        Assert.assertEquals(2, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCatWithNoCapacity() {
        House house = new House(DEFAULT_NAME, DEFAULT_CAPACITY);
        for (int i = 0; i <= 6; i++) {
            house.addCat(new Cat("testCat"));
        }
    }

    @Test
    public void removeCat() {
        House house = addCatsToHouse();
        Assert.assertEquals(2, house.getCount());
        house.removeCat("testCat1");
        Assert.assertEquals(1, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void removeCatIfCatInputIsNull() {
        House house = addCatsToHouse();
        house.removeCat("myCat");
    }

    @Test
    public void testCatForSale() {
        House house = addCatsToHouse();
        Cat cat = house.catForSale("testCat1");

        Assert.assertFalse(cat.isHungry());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCatForSaleThrowsException() {
        House house = addCatsToHouse();
        Cat cat = house.catForSale("myCat");
    }

    @Test
    public void testStatistics() {
        House house = addCatsToHouse();
        String expectedStatistics = "The cat testCat1, testCat2 is in the house My House!";
        Assert.assertEquals(expectedStatistics, house.statistics());
    }
}
